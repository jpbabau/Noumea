package testWMS.WPSpackage;

import java.io.IOException;
import java.util.*;

import org.geotools.process.factory.DescribeParameter;
import org.geotools.process.factory.DescribeProcess;
import org.geotools.process.factory.DescribeResult;
import org.geotools.process.factory.StaticMethodsProcessFactory;
import org.geotools.text.Text;
import org.geotools.feature.FeatureCollection;
import org.geotools.ows.ServiceException;
import org.opengis.feature.simple.*;
import java.awt.image.BufferedImage;
import com.vividsolutions.jts.geom.*;

import com.vividsolutions.jts.io.ParseException;

import remoteWpsCall.*;

import Images.ImageUtils;
import Images.ImageUtils;
import Math.MathUtils;

public class ImageAnalysis_class extends StaticMethodsProcessFactory<ImageAnalysis_class>
{
		protected static ImageUtils callObject_1;
		protected static ImageUtils callObject_2;
		protected static MathUtils callObject_3;

	public ImageAnalysis_class() {
		super(Text.text(""),"testWMS",ImageAnalysis_class.class);
		callObject_1 = new ImageUtils();
		callObject_2 = new ImageUtils();
		callObject_3 = new MathUtils();
	}

	@DescribeProcess(title="imageAnalysis",description="")
	@DescribeResult(name="result",description="")
	public static Integer imageAnalysis() {
		BufferedImage  inputImage_wps1;
		Integer numberPixels_wps1 = 0;
		BufferedImage  inputImage_wps2;
		Integer numberPixels_wps2 = 0;
		Integer input1i_wps3 = 0;	
		Integer input2i_wps3 = 0;	
		Integer resultAi_wps3 = 0;
		BufferedImage  rdImage1 = null;
		BufferedImage  rdImage2 = null;
		Integer result;
		try {
			WMSrequest aWMSrequest1 = new WMSrequest("sampleserver1.arcgisonline.com/ArcGIS/services/Specialty/ESRI_StatesCitiesRivers_USA/MapServer/WMSServer",0,"png",420,583,false,"EPSG:4326",-131.13151509433965,-117.61620566037737,46.60532747661736,56.34191403281659);
			rdImage1= aWMSrequest1.Call();
			WMSrequest aWMSrequest2 = new WMSrequest("sampleserver1.arcgisonline.com/ArcGIS/services/Specialty/ESRI_StatesCitiesRivers_USA/MapServer/WMSServer",0,"png",420,583,false,"EPSG:4326",-131.13151509433965,-117.61620566037737,46.60532747661736,56.34191403281659);
			rdImage2= aWMSrequest2.Call();
		} catch (ServiceException | IOException e) {
			e.printStackTrace();
		}
		inputImage_wps1 = rdImage1;
		inputImage_wps2 = rdImage2;
		numberPixels_wps1 = callObject_1.numberPixelsImage(inputImage_wps1);	
		input1i_wps3=numberPixels_wps1;
		numberPixels_wps2 = callObject_2.numberPixelsImage(inputImage_wps2);	
		input2i_wps3=numberPixels_wps2;
		resultAi_wps3 = callObject_3.intAddBody(input1i_wps3,input2i_wps3);	
		result=resultAi_wps3;	
		return result;	
	}
}

package tests;

public class testGeneration {

	public static void main(String[] args) {
		
		System.out.println("test Program");
	}
}
package remoteWpsCall;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import org.geotools.data.DataStore;
import org.geotools.data.DataStoreFinder;
import org.geotools.data.DefaultTransaction;
import org.geotools.data.FeatureStore;
import org.geotools.data.Transaction;
import org.geotools.data.simple.*;
import org.geotools.data.wfs.WFSDataStore;
import org.geotools.data.wfs.WFSDataStoreFactory;
import org.geotools.feature.FeatureCollection;
import org.opengis.feature.Feature;
import org.opengis.feature.simple.SimpleFeature;
import org.opengis.feature.simple.SimpleFeatureType;
import org.geotools.xml.XMLSAXHandler;
import org.opengis.filter.FilterFactory;

public class WFSrequest {

		private String ServerName ;
		private int versionNumber;
		
	    private WFSDataStore wfs;
		
	public WFSrequest(String urlName, int aVersionNumber) {
				this.ServerName = urlName;
				this.versionNumber = 0;
				if (aVersionNumber == 1) {this.versionNumber = aVersionNumber;}
		}
		
	public FeatureCollection<SimpleFeatureType, SimpleFeature> Call( ) {
			
			FeatureCollection<SimpleFeatureType, SimpleFeature> retour = null;
		
			URL url = null;
			try {
				url = new URL("http://"+ServerName+"?VERSION=1.1.1&Request=GetCapabilities&Service=WFS");
				XMLSAXHandler.setLogLevel(Level.OFF); 
		        Map connectionParameters  = new HashMap();
		        connectionParameters .put(WFSDataStoreFactory.URL.key, url);
		        WFSDataStoreFactory  dsf = new WFSDataStoreFactory();
		        wfs = dsf.createDataStore(connectionParameters);
		        String typeNames[] = wfs.getTypeNames();
		        String typeName = typeNames[0];
		        SimpleFeatureType schema = wfs.getSchema( typeName );
		        
		        SimpleFeatureSource source = wfs.getFeatureSource( typeName );

		        retour = source.getFeatures();

		      } catch (MalformedURLException e) {
		        e.printStackTrace();
		      } catch (IOException e) {
		        e.printStackTrace();
		     }

			return retour;
	}
}

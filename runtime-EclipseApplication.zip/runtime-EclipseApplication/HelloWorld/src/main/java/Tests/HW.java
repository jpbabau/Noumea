package Tests;

public class HW {
	
	public String helloWorld(String world) {
		return ("Hello "+world);
	}
}

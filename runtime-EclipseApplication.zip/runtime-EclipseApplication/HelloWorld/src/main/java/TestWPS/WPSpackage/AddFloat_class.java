package TestWPS.WPSpackage;

import org.geotools.process.factory.*;
import org.geotools.text.Text;
import org.geotools.feature.FeatureCollection;
import org.opengis.feature.simple.*;
import java.awt.image.BufferedImage;

import com.vividsolutions.jts.geom.*;

import Math.MathUtils;

public class AddFloat_class extends StaticMethodsProcessFactory<AddFloat_class> {
	
	protected static MathUtils callObject;

	public AddFloat_class() {
		super(Text.text("testsonWPS"),"TestWPS",AddFloat_class.class);
		callObject = new MathUtils();
	}

	@DescribeProcess(title="addFloat",description="sumofdouble")
	@DescribeResult(name="resultAd",description="addofthetwoinputs")
	public static Double addFloat(@DescribeParameter(name="input1d",description=" firstoperand") Double input1d,@DescribeParameter(name="input2d",description=" secondoperand") Double input2d) {
		Double resultAd;
		resultAd = callObject.doubleAddBody( input1d, input2d);

		return resultAd;
	}
}

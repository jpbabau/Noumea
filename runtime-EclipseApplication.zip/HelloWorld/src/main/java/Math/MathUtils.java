package Math;

public class MathUtils {
	
	public int intAddBody(int value1, int value2) {
		return (value1+value2);
	}
	
	public double doubleAddBody(double value1, double value2) {
		return (value1+value2);
	}
}

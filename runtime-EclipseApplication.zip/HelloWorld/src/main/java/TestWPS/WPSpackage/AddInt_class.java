package TestWPS.WPSpackage;

import org.geotools.process.factory.*;
import org.geotools.text.Text;
import org.geotools.feature.FeatureCollection;
import org.opengis.feature.simple.*;
import java.awt.image.BufferedImage;

import com.vividsolutions.jts.geom.*;

import Math.MathUtils;

public class AddInt_class extends StaticMethodsProcessFactory<AddInt_class> {
	
	protected static MathUtils callObject;

	public AddInt_class() {
		super(Text.text("WPS"),"TestWPS",AddInt_class.class);
		callObject = new MathUtils();
	}

	@DescribeProcess(title="addInt",description="integers")
	@DescribeResult(name="resultAi",description="inputs")
	public static Integer addInt(@DescribeParameter(name="input1i",description=" operand") Integer input1i,@DescribeParameter(name="input2i",description=" operand") Integer input2i) {
		Integer resultAi;
		resultAi = callObject.intAddBody( input1i, input2i);

		return resultAi;
	}
}

package TestWPS.WPSpackage;

import java.io.IOException;
import java.util.*;

import org.geotools.process.factory.DescribeParameter;
import org.geotools.process.factory.DescribeProcess;
import org.geotools.process.factory.DescribeResult;
import org.geotools.process.factory.StaticMethodsProcessFactory;
import org.geotools.text.Text;
import org.geotools.feature.FeatureCollection;
import org.opengis.feature.simple.*;
import java.awt.image.BufferedImage;
import com.vividsolutions.jts.geom.*;

import com.vividsolutions.jts.io.ParseException;

import remoteWpsCall.*;

import Math.MathUtils;
import Math.MathUtils;

public class TestGeneration_class extends StaticMethodsProcessFactory<TestGeneration_class>
{
		protected static MathUtils callObject_1;
		protected static MathUtils callObject_3;

	public TestGeneration_class() {
		super(Text.text("WPS"),"TestWPS",TestGeneration_class.class);
		callObject_1 = new MathUtils();
		callObject_3 = new MathUtils();
	}

	@DescribeProcess(title="testGeneration",description="WPS")
	@DescribeResult(name="result",description="operands")
	public static Integer testGeneration(@DescribeParameter(name="input1",description=" operand") Integer input1,@DescribeParameter(name="input2",description=" operand") Integer input2) {
		Integer input1i_wps1 = 0;	
		Integer input2i_wps1 = 0;	
		Integer resultAi_wps1 = 0;
		Integer v1_wps2 = 0;	
		Integer v2_wps2 = 0;	
		Integer resultRi_wps2 = 0;
		Integer input1i_wps3 = 0;	
		Integer input2i_wps3 = 0;	
		Integer resultAi_wps3 = 0;
		Integer result;
		input1i_wps1=input1;
		input2i_wps1=input2;
		v2_wps2=input2;
		input2i_wps3=14;



		resultAi_wps1 = callObject_1.intAddBody(input1i_wps1,input2i_wps1);	
		v1_wps2=resultAi_wps1;
	    RemoteWpsCall wpscall2= new RemoteWpsCall("http://localhost:8080/geoserver/ows","TestWPS:addInt");
		ArrayList<Object> inputs2= new ArrayList<Object>();
		inputs2.add(v1_wps2);
		inputs2.add(v2_wps2);
		String resultRwps2;
		try { 
			resultRwps2 = wpscall2.Request(inputs2);
			resultRi_wps2 = Integer.parseInt(resultRwps2);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		input1i_wps3=resultRi_wps2;
		resultAi_wps3 = callObject_3.intAddBody(input1i_wps3,input2i_wps3);	
		result=resultAi_wps3;	
		return result;	
	}
}

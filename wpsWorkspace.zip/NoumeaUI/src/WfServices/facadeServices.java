package WfServices;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.JavaModelException;

import wfwps.*;

import com.facade.interfaceServices;

import utils.utilsProcessFactory;

public class facadeServices implements interfaceServices {
	
	WfWpsServices theWfWpsServices;
	WfWpsLibServices libModel;
	utilsProcessFactory utilFile;
	String fileName;
	
	public facadeServices() {
		theWfWpsServices = new WfWpsServices();
		libModel = new WfWpsLibServices();
		utilFile = new utilsProcessFactory();
	}
	
	public boolean AddModel(String name, String packageName, String className, IMethod function, String returnName) {
		libModel.LoadLibFile();
		boolean addOK = libModel.addLocalWPS(name, packageName, className,function.getElementName());
		if (addOK) {
			try {
				libModel.addInputs(function.getParameterNames(),function.getParameterTypes());
				libModel.addOutput(returnName,function.getReturnType());
			} catch (JavaModelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			libModel.Save();
		}
		return addOK;
	}
	
	public void setFile(File file) {
		theWfWpsServices.setLibFileName(file.getAbsolutePath());
		libModel.setLibFileName(file.getAbsolutePath());
		fileName = file.getAbsolutePath();
	}
	
	public String getFileName(){
		return fileName;
	}
	
	public List<String> getLocalWpsList(){
		
		ArrayList <String> localWpsList = new ArrayList<String>();

		for (LocalWPS wps : theWfWpsServices.getLocalWPS()) {
			localWpsList.add(wps.getName());
		}
		return localWpsList;
	}
	
	public List<String> getRemoteWpsList(){
		
		ArrayList <String> remoteWpsList = new ArrayList<String>();

		for (RemoteWPS wps : theWfWpsServices.getRemoteWPS()) {
			remoteWpsList.add(wps.getName());
		}
		return remoteWpsList;
	}
	
	public List<String> getWorkFlowList(){
		
		ArrayList <String> listWorkflow = new ArrayList<String>();
		
		for (WorkFlow wf : theWfWpsServices.getWF()) {
			listWorkflow.add(wf.getName());
		}
		return listWorkflow;
	}
	
	public String generate(String folderName){
		String result = "";
		List<Integer> theWpsId = new ArrayList<Integer>();
		theWfWpsServices.LoadLibFile();
		for (int idWps = 0; idWps < theWfWpsServices.getLocalWPS().size(); idWps++) {
			theWpsId.add(idWps);
		}
		result += this.generateLocalWPS(theWpsId, folderName);
		List<Integer> theWfId = new ArrayList<Integer>();
		for (int idWf = 0; idWf < theWfWpsServices.getWF().size(); idWf++) {
			theWfId.add(idWf);
		}
		result += this.generateWF(theWfId, folderName);
		return result;
	}

	public String generateLocalWPS(List<Integer> idWps, String folderName) {
		String result = "";
		theWfWpsServices.LoadLibFile();
		for (Integer id : idWps) {
			if (id>=0 && id <theWfWpsServices.getLocalWPS().size()) {
				if (theWfWpsServices.isOK(theWfWpsServices.getLocalWPS().get(id))) {
					theWfWpsServices.generateLocalWPS(theWfWpsServices.getLocalWPS().get(id), folderName+"/src/main/java/"+theWfWpsServices.getProjectName()+"/WPSpackage");
					try {
						String className = Character.toUpperCase(theWfWpsServices.getLocalWPS().get(id).getName().charAt(0)) + theWfWpsServices.getLocalWPS().get(id).getName().substring(1);
						utilFile.addClassName(folderName, theWfWpsServices.getProjectName(),className);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					result+="impossible to generate code due to modelling errors, check model of: "+(theWfWpsServices.getLocalWPS().get(id).getName());
				}
			}
		}
		return result;
	}

	public String generateWF(List<Integer> idWf, String folderName) {
		String result = "";
		theWfWpsServices.LoadLibFile();
		for (Integer id : idWf) {
			if (id>=0 && id <theWfWpsServices.getWF().size()) {
				if (theWfWpsServices.isOK(theWfWpsServices.getWF().get(id))) {
					boolean noCycle = theWfWpsServices.generateWF(theWfWpsServices.getWF().get(id), folderName+"/src/main/java/"+theWfWpsServices.getProjectName()+"/WPSpackage");
					if (!noCycle) {
						result+="impossible to generate code for "+(theWfWpsServices.getWF().get(id).getName()+" : presence of cycle in the model");						
					} else {
					try {
						String className = Character.toUpperCase(theWfWpsServices.getWF().get(id).getName().charAt(0)) + theWfWpsServices.getWF().get(id).getName().substring(1);
						utilFile.addClassName(folderName, theWfWpsServices.getProjectName(),className);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}}
				} else {
					result+="impossible to generate code for "+(theWfWpsServices.getWF().get(id).getName()+" : modelling errors, correct and check the model");
				}			
			}
		}
		return result;
	}
}

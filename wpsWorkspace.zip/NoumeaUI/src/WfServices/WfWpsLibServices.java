package WfServices;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.eclipse.emf.common.util.*;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import wfwps.*;
import wfwps.impl.*;


public class WfWpsLibServices {

	private static final List<String> typesJava = Stream.of("I", "D", "Z","QString;","QBufferedImage;","QGeometry;","QFeatureCollection<QSimpleFeatureType;QSimpleFeature;>;").collect(Collectors.toList());
	
	WorflowWps myWorflowWps;
	String fileName;
	Resource resource;
	
	WfwpsFactory theFactory;
	LocalWPS newWPS;
	
	public WfWpsLibServices() {
	}
	
	public void setLibFileName(String filename) {
	       fileName = filename;
	}
	
	public void LoadLibFile() {
        // Initialize the model
       WfwpsPackage.eINSTANCE.eClass();

        // Register the XMI resource factory for the extension
        Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
        Map<String, Object> m = reg.getExtensionToFactoryMap();
        m.put("wfwps", new XMIResourceFactoryImpl());

        // Obtain a new resource set
        ResourceSet resSet = new ResourceSetImpl();

        // Get the resource
        String urlName = "file:///"+fileName.replace("\\", "/");
        resource = resSet.getResource(URI.createURI(urlName), true);

        myWorflowWps = (WorflowWps) resource.getContents().get(0);
	}
	
	public boolean addLocalWPS(String name, String packageName, String className, String functionName) {
		
		boolean okWPS = true;

		for (LocalWPS wps : myWorflowWps.getLocalWpsLibrary()) {
			if (wps.getFunctionName().equals(functionName)&&wps.getClassName().equals(className)&&wps.getPackageName().equals(packageName)) {
				okWPS = false;
			}
		}
		if (okWPS) {
			theFactory = new WfwpsFactoryImpl();
		
			newWPS = theFactory.createLocalWPS();
			newWPS.setPackageName(packageName);
			newWPS.setClassName(className);
			newWPS.setFunctionName(functionName);
			newWPS.setName(name);
			newWPS.setAbstract("Add a description of "+name);
			myWorflowWps.getLocalWpsLibrary().add(newWPS);
		}
		return okWPS;
	}

	public void addInputs(String[] parameterNames, String[] parameterTypes) {
		
		for (int i = 0; i < parameterNames.length; i++) {
			Input input = theFactory.createInput();
			input.setName(parameterNames[i]);
			input.setLowerBound(1);
			input.setUpperBound(1);
			int typeNumber = typesJava.lastIndexOf(parameterTypes[i]);
			switch (typeNumber) {
			case 0:		input.setType(wfwps.WPStype.INTEGER);break;
			case 1:		input.setType(wfwps.WPStype.DOUBLE);break;
			case 2:		input.setType(wfwps.WPStype.BOOLEAN);break;
			case 3:		input.setType(wfwps.WPStype.STRING);break;
			case 4:		input.setType(wfwps.WPStype.RASTER);break;
			case 5:		input.setType(wfwps.WPStype.GEOMETRY);break;
			case 6:		input.setType(wfwps.WPStype.COMPLEX);break;
			default:	input.setType(wfwps.WPStype.INTEGER);break;
			}
			newWPS.getInputs().add(input);
		}
	}

	public void addOutput(String returnName, String returnType) {
		Output output = theFactory.createOutput();
		output.setName(returnName);
		output.setLowerBound(1);
		output.setUpperBound(1);
		int typeNumber = typesJava.lastIndexOf(returnType);
		switch (typeNumber) {
		case 0:		output.setType(wfwps.WPStype.INTEGER);break;
		case 1:		output.setType(wfwps.WPStype.DOUBLE);break;
		case 2:		output.setType(wfwps.WPStype.BOOLEAN);break;
		case 3:		output.setType(wfwps.WPStype.STRING);break;
		case 4:		output.setType(wfwps.WPStype.RASTER);break;
		case 5:		output.setType(wfwps.WPStype.GEOMETRY);break;
		case 6:		output.setType(wfwps.WPStype.COMPLEX);break;
		default:	output.setType(wfwps.WPStype.INTEGER);break;
		}
		newWPS.getOutputs().add(output);
	}

	public void Save() {
		resource.getContents().add(myWorflowWps);
        try {
            resource.save(Collections.EMPTY_MAP);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}
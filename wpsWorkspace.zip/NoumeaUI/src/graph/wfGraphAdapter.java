package graph;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Objects;

import wfwps.*;

public class wfGraphAdapter {
	
	WorkFlow theWF;
	Graph theGraph;
	HashMap<WPSReference, Node> wpsNodes;
	
	public Graph getTheGraph() {
		return theGraph;
	}
	
	public wfGraphAdapter(WorkFlow aWF) {
		
		theWF = aWF;
		theGraph = new Graph();
		wpsNodes = new HashMap<WPSReference, Node>();
		
		for (WPSReference wps : aWF.getWps()) {
			Node node = new Node();
			theGraph.getNodes().add(node);
			wpsNodes.put(wps, node);
		}
		
		for (Link link : aWF.getLinks()) {
			Edge edge = new Edge();
			theGraph.getEdges().add(edge);
			if ((link.getInput() instanceof OutputReference) && (link.getOutput() instanceof InputReference)) {
				edge.setFrom(wpsNodes.get(link.getInput().eContainer()));
				edge.setTo(wpsNodes.get(link.getOutput().eContainer()));
			}
		}
	}
	
	public boolean preOrder() {
		GraphOrder aGraphOrder = new GraphOrder(theGraph);
		boolean result = aGraphOrder.preOrder();	
		theWF.getWps().clear();
		for (Node node : theGraph.getNodes()) {
		    for (Entry<WPSReference,Node> entry : wpsNodes.entrySet()) {
		        if (Objects.equals(node, entry.getValue())) {
					theWF.getWps().add(entry.getKey());
		        }
		    }
		}
		return result;
	}
}

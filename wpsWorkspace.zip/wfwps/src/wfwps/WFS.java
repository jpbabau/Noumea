/**
 */
package wfwps;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>WFS</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wfwps.WfwpsPackage#getWFS()
 * @model
 * @generated
 */
public interface WFS extends RemoteData {
} // WFS

/**
 */
package wfwps;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Local WPS</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wfwps.WfwpsPackage#getLocalWPS()
 * @model
 * @generated
 */
public interface LocalWPS extends WPS, Implementable {
} // LocalWPS

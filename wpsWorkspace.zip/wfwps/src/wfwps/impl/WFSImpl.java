/**
 */
package wfwps.impl;

import org.eclipse.emf.ecore.EClass;

import wfwps.WFS;
import wfwps.WfwpsPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>WFS</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class WFSImpl extends RemoteDataImpl implements WFS {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WFSImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WfwpsPackage.Literals.WFS;
	}

} //WFSImpl

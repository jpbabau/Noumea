/**
 */
package wfwps.tests;

import junit.framework.TestCase;

import wfwps.OutputLink;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Output Link</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class OutputLinkTest extends TestCase {

	/**
	 * The fixture for this Output Link test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OutputLink fixture = null;

	/**
	 * Constructs a new Output Link test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutputLinkTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Output Link test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(OutputLink fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Output Link test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OutputLink getFixture() {
		return fixture;
	}

} //OutputLinkTest

/**
 */
package wfwps.tests;

import junit.framework.TestCase;

import wfwps.DescribedElement;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Described Element</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class DescribedElementTest extends TestCase {

	/**
	 * The fixture for this Described Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DescribedElement fixture = null;

	/**
	 * Constructs a new Described Element test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DescribedElementTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Described Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(DescribedElement fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Described Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DescribedElement getFixture() {
		return fixture;
	}

} //DescribedElementTest

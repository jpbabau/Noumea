/**
 */
package wfwps.tests;

import junit.framework.TestCase;

import wfwps.InputLink;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Input Link</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class InputLinkTest extends TestCase {

	/**
	 * The fixture for this Input Link test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InputLink fixture = null;

	/**
	 * Constructs a new Input Link test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputLinkTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Input Link test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(InputLink fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Input Link test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InputLink getFixture() {
		return fixture;
	}

} //InputLinkTest

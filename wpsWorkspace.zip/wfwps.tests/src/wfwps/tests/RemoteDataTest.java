/**
 */
package wfwps.tests;

import wfwps.RemoteData;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Remote Data</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class RemoteDataTest extends InputLinkTest {

	/**
	 * Constructs a new Remote Data test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RemoteDataTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Remote Data test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected RemoteData getFixture() {
		return (RemoteData)fixture;
	}

} //RemoteDataTest

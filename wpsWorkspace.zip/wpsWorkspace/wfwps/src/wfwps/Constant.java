/**
 */
package wfwps;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Constant</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wfwps.WfwpsPackage#getConstant()
 * @model abstract="true"
 * @generated
 */
public interface Constant extends InputLink, DescribedElement {
} // Constant

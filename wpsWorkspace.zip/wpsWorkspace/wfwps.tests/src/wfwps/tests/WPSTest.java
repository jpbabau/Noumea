/**
 */
package wfwps.tests;

import wfwps.WPS;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>WPS</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class WPSTest extends DescribedElementTest {

	/**
	 * Constructs a new WPS test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WPSTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this WPS test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected WPS getFixture() {
		return (WPS)fixture;
	}

} //WPSTest

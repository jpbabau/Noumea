package com.facade;

import java.io.File;
import java.util.List;

import org.eclipse.jdt.core.IMethod;

public interface interfaceServices {
	
	
	public String getFileName();
	
	public List<String> getLocalWpsList();
	
	public List<String> getRemoteWpsList();
	
	public List<String> getWorkFlowList();
	
	public String generate(String folderName);

	public String generateLocalWPS(List<Integer> idWps,String folderName);
	
	public String generateWF(List<Integer> idWf,String folderName);
	
	public void setFile(File file);

	public boolean AddModel(String string, String text, String text2, IMethod theMethod, String string2);
	
}
